import React from 'react'


const Footer = () => {
   let Bottom={
           position:"absolute",
           top:"160vh"
    }
    return (
        <>
        <div style={Bottom}>
            Conducted &copy; By NSS IIT ROORKEE
        </div>
        
        </>
        
    )
}
export default Footer