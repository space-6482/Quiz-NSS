import React from 'react'

const Data = () => {
    let Data={
        position:"Absolute",
        left:"50vh",
        margin:"5vh"
    }
    return (
        <div>
           
             kya kkru bhia
            
        </div>
    )
}

export default Data
