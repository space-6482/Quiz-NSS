import React from 'react'

const Text = () => {
    return (
        <div>

            <h1> This is a text component and this is a jsx file
                This is a text component and this is a jsx file
            </h1>
        </div>
    )
}

export default Text
