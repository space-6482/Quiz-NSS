import React from 'react';
import Footer from './Footer';
import Header from './Header'
import Main from './Main'

// import Form from './Components/Form';


const Block = () => {
        return (

                <div>
                        {/* <Form/> */} 
                        <Header/>
                        <Main/>
                        <Footer/> 
                </div>
        )
}

export default Block
