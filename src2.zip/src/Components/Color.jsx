import React from 'react'

const Color = () => {
    return (
        <div>
            
<h1>  This is color column here you can see all the material that is available in this website </h1>       
 </div>
    )
}

export default Color
